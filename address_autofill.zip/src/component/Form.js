import  React, { useEffect, useState } from "react";
import { AddressAutofill } from "@mapbox/search-js-react";
import axios from "axios";


const ADDRESS_TOKEN = "pk.eyJ1Ijoibml0aW5jaGlrYW5pIiwiYSI6ImNsaHJibHhpNTBkNnQzbG13dThzeWxuNTUifQ.n805py9K8WZqAdIbyBZu9g"

export default function Form() {  
  const [user, setUser] = useState({
    address:'',
    apartment:"",
    city:'',
    state:'',
    postcode:'',
    country:''
  })
  useEffect(()=>{
  
  },[]) 
  const searchAddres = async () => {
    const res = await axios.get()
  }
  const {address, apartment, city, state, country, postcode} = user
 console.log('user', user)
  const handleChange = (e) => {
    setUser({...user,[e.target.name]:e.target.value})
  }
let userData = user.toString().st?.map((itmes)=> console.log('itmes', itmes))
console.log('userData =>', userData)
  const autoComplete = () => {
    let arr = ['address-line1', 'address-level2', 'address-level1', "country-name", "Postcode"]
    for(let i=0; i<=arr.length -1; i++){
     let data = arr[i]
      console.log('data', data)       
    }
  }
  return (
    <React.Fragment>
      <div className="form">
     <form >
<AddressAutofill accessToken={ADDRESS_TOKEN}>
  <label> address:</label>
<input
name="address" 
placeholder="Address" type="text"

autoComplete="address-line1"
/>
</AddressAutofill>
<div>
<label>Apartment number:</label>
<input
name="apartment" 
placeholder="Apartment number" type="text" value={apartment}
onChange={handleChange}
autoComplete="address-line2 "
/>
</div>
<div>
<label>City:</label>
<input
name="city" 
placeholder="City" type="text"
onChange={handleChange}
value={city}
autoComplete="address-level2"
/>
</div>

<div>
<label>State:</label>
<input
name="state" value={state} 
placeholder="State" type="text"
onChange={handleChange}
autoComplete="address-level1"
/>
</div>

<div>
<label>Country:</label>

<input
name="country" 
placeholder="Country" type="text"
onChange={handleChange}
autoComplete="country-name" value={country}
/>
</div>

<div>
<label>Postcode:</label>
<input
name="postcode" 
placeholder="Postcode" type="text"
onChange={handleChange}
autoComplete="postal-code" value={postcode}
/>
<button type="button" onClick={autoComplete}>button</button>
</div>
</form>
</div>
    </React.Fragment>
  );
}
